package net.sourceforge.opencamera;

/** Filutro captures photos only; all mode requests resolve to the photo pipeline. */
public final class FilutroPhotoOnlyPolicy {
    private FilutroPhotoOnlyPolicy() {
    }

    public static boolean shouldUseVideoMode(boolean requestedVideoMode) {
        return false;
    }
}
