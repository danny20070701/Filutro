package net.sourceforge.opencamera;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.util.List;

/** Composites sequential stills with a photographic screen blend. */
final class FilutroMultipleExposureProcessor {
    private static final int MAX_OUTPUT_PIXELS = 24 * 1024 * 1024;
    private static final int MAX_PREVIEW_PIXELS = 2 * 1024 * 1024;

    private FilutroMultipleExposureProcessor() {
    }

    static Bitmap compose(List<byte[]> frames) {
        if( frames == null || frames.size() < 2 || frames.size() > 4 ) {
            throw new IllegalArgumentException("Multiple exposure needs two to four frames");
        }
        return compose(frames, MAX_OUTPUT_PIXELS);
    }

    /** Creates the lightweight, upright composition shown between multiple-exposure shutter presses. */
    static Bitmap composePreview(List<byte[]> frames) {
        if( frames == null || frames.isEmpty() || frames.size() > 4 ) {
            throw new IllegalArgumentException("Multiple exposure preview needs one to four frames");
        }
        return compose(frames, MAX_PREVIEW_PIXELS);
    }

    private static Bitmap compose(List<byte[]> frames, int maxPixels) {
        int sampleSize = sampleSizeFor(frames.get(0), maxPixels);
        Bitmap composite = decode(frames.get(0), frames.size() > 1, sampleSize);
        if( composite == null ) {
            return null;
        }
        try {
            for(int i = 1; i < frames.size(); i++) {
                Bitmap next = decode(frames.get(i), false, sampleSize);
                if( next == null || next.getWidth() != composite.getWidth() || next.getHeight() != composite.getHeight() ) {
                    if( next != null ) {
                        next.recycle();
                    }
                    composite.recycle();
                    return null;
                }
                blendInto(composite, next);
                next.recycle();
            }
            return composite;
        }
        catch(RuntimeException e) {
            composite.recycle();
            throw e;
        }
    }

    static int screenBlend(int base, int overlay) {
        int alpha = Math.max((base >>> 24) & 0xFF, (overlay >>> 24) & 0xFF);
        int red = screenChannel((base >>> 16) & 0xFF, (overlay >>> 16) & 0xFF);
        int green = screenChannel((base >>> 8) & 0xFF, (overlay >>> 8) & 0xFF);
        int blue = screenChannel(base & 0xFF, overlay & 0xFF);
        return (alpha << 24) | (red << 16) | (green << 8) | blue;
    }

    private static void blendInto(Bitmap composite, Bitmap next) {
        int width = composite.getWidth();
        int[] basePixels = new int[width];
        int[] overlayPixels = new int[width];
        for(int y = 0; y < composite.getHeight(); y++) {
            composite.getPixels(basePixels, 0, width, 0, y, width, 1);
            next.getPixels(overlayPixels, 0, width, 0, y, width, 1);
            for(int x = 0; x < width; x++) {
                basePixels[x] = screenBlend(basePixels[x], overlayPixels[x]);
            }
            composite.setPixels(basePixels, 0, width, 0, y, width, 1);
        }
    }

    private static Bitmap decode(byte[] jpeg, boolean mutable, int sampleSize) {
        Bitmap bitmap = ImageUtils.loadBitmap(jpeg, mutable, sampleSize);
        return ImageUtils.rotateForExif(bitmap, jpeg);
    }

    private static int sampleSizeFor(byte[] jpeg, int maxPixels) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(jpeg, 0, jpeg.length, options);
        long pixels = (long)options.outWidth * options.outHeight;
        int sample = 1;
        while( pixels / ((long)sample * sample) > maxPixels ) {
            sample *= 2;
        }
        return sample;
    }

    private static int screenChannel(int base, int overlay) {
        return 255 - ((255 - base) * (255 - overlay) / 255);
    }
}
