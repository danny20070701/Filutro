package net.sourceforge.opencamera.preview.camerasurface;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.opengl.GLES11Ext;
import android.opengl.GLES30;
import android.opengl.GLSurfaceView;
import android.media.MediaRecorder;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import net.sourceforge.opencamera.FilutroCubeLut;
import net.sourceforge.opencamera.FilutroLutPresets;
import net.sourceforge.opencamera.FilutroLutStore;
import net.sourceforge.opencamera.MyDebug;
import net.sourceforge.opencamera.cameracontroller.CameraController;
import net.sourceforge.opencamera.cameracontroller.CameraControllerException;
import net.sourceforge.opencamera.preview.Preview;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.concurrent.atomic.AtomicBoolean;

/** Camera2 preview surface that grades Camera2 frames on the GPU with the selected 3D LUT. */
public final class FilutroLutSurface extends GLSurfaceView implements CameraSurface {
    private static final String TAG = "FilutroLutSurface";

    private final Preview preview;
    private final int[] measureSpec = new int[2];
    private final FilutroLutStore lutStore;
    private final Renderer renderer;

    public FilutroLutSurface(Context context, Preview preview) {
        super(context);
        this.preview = preview;
        this.lutStore = new FilutroLutStore(context);
        this.renderer = new Renderer();
        setEGLContextClientVersion(3);
        setPreserveEGLContextOnPause(true);
        setRenderer(renderer);
        setRenderMode(RENDERMODE_WHEN_DIRTY);
    }

    @Override
    public View getView() {
        return this;
    }

    @Override
    public void setPreviewDisplay(CameraController cameraController) {
        SurfaceTexture texture = renderer.getCameraTexture();
        if( texture == null ) {
            throw new IllegalStateException("LUT preview texture is not ready");
        }
        try {
            cameraController.setPreviewTexture(texture);
        }
        catch(CameraControllerException e) {
            MyDebug.logStackTrace(TAG, "failed to attach GPU preview surface", e);
        }
    }

    @Override
    public void setVideoRecorder(MediaRecorder videoRecorder) {
        // Filutro is photo-only. Camera preview remains on the GPU texture.
    }

    @Override
    public void setTransform(Matrix matrix) {
        // Preview is sized to the selected camera aspect ratio. Rotation is handled in the renderer.
    }

    /** Mirrors Open Camera's Camera2 TextureView display transform in GPU sampling coordinates. */
    public void setCameraTransform(int displayRotationDegrees, boolean correctFrontLandscape) {
        renderer.setCameraTransform(displayRotationDegrees, correctFrontLandscape);
        requestRender();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return preview.touchEvent(event);
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        preview.getMeasureSpec(measureSpec, widthSpec, heightSpec);
        super.onMeasure(measureSpec[0], measureSpec[1]);
    }

    private final class Renderer implements GLSurfaceView.Renderer {
        private final FloatBuffer vertices = ByteBuffer.allocateDirect(16 * Float.BYTES)
                .order(ByteOrder.nativeOrder())
                .asFloatBuffer()
                .put(new float[] {
                        -1f, -1f, 0f, 0f,
                         1f, -1f, 1f, 0f,
                        -1f,  1f, 0f, 1f,
                         1f,  1f, 1f, 1f
                });
        private final float[] textureTransform = new float[16];
        private final AtomicBoolean frameAvailable = new AtomicBoolean();

        private volatile SurfaceTexture cameraTexture;
        private int cameraTextureId;
        private int lutTextureId;
        private int program;
        private String uploadedLutId;
        private volatile int rotationDegrees;
        private volatile boolean correctFrontLandscape;

        Renderer() {
            vertices.position(0);
        }

        SurfaceTexture getCameraTexture() {
            return cameraTexture;
        }

        void setCameraTransform(int rotationDegrees, boolean correctFrontLandscape) {
            this.rotationDegrees = rotationDegrees;
            this.correctFrontLandscape = correctFrontLandscape;
        }

        @Override
        public void onSurfaceCreated(javax.microedition.khronos.opengles.GL10 gl, javax.microedition.khronos.egl.EGLConfig config) {
            program = createProgram(VERTEX_SHADER, FRAGMENT_SHADER);
            int[] textures = new int[2];
            GLES30.glGenTextures(2, textures, 0);
            cameraTextureId = textures[0];
            lutTextureId = textures[1];

            GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, cameraTextureId);
            GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR);
            GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
            GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE);
            GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);

            SurfaceTexture texture = new SurfaceTexture(cameraTextureId);
            texture.setOnFrameAvailableListener(surfaceTexture -> {
                frameAvailable.set(true);
                requestRender();
            });
            cameraTexture = texture;
            uploadedLutId = null;
            post(() -> preview.onFilutroLutSurfaceReady(getWidth(), getHeight()));
        }

        @Override
        public void onSurfaceChanged(javax.microedition.khronos.opengles.GL10 gl, int width, int height) {
            GLES30.glViewport(0, 0, width, height);
        }

        @Override
        public void onDrawFrame(javax.microedition.khronos.opengles.GL10 gl) {
            SurfaceTexture texture = cameraTexture;
            if( texture == null ) {
                return;
            }
            if( frameAvailable.compareAndSet(true, false) ) {
                texture.updateTexImage();
            }
            texture.getTransformMatrix(textureTransform);
            updateLut();
            draw();
        }

        private void updateLut() {
            String selectedId = lutStore.selectedId();
            if( selectedId.equals(uploadedLutId) ) {
                return;
            }
            FilutroCubeLut lut;
            try {
                lut = lutStore.selectedLut();
            }
            catch(IOException e) {
                MyDebug.logStackTrace(TAG, "failed to load LUT preview", e);
                lut = FilutroLutPresets.forId(FilutroLutPresets.NEUTRAL);
            }
            ByteBuffer data = ByteBuffer.allocateDirect(lut.toRgbBytes().length).order(ByteOrder.nativeOrder());
            data.put(lut.toRgbBytes()).position(0);
            GLES30.glBindTexture(GLES30.GL_TEXTURE_3D, lutTextureId);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE);
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, GLES30.GL_TEXTURE_WRAP_R, GLES30.GL_CLAMP_TO_EDGE);
            GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1);
            GLES30.glTexImage3D(GLES30.GL_TEXTURE_3D, 0, GLES30.GL_RGB8, lut.size(), lut.size(), lut.size(), 0, GLES30.GL_RGB, GLES30.GL_UNSIGNED_BYTE, data);
            uploadedLutId = selectedId;
        }

        private void draw() {
            GLES30.glClearColor(0f, 0f, 0f, 1f);
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT);
            GLES30.glUseProgram(program);
            int position = GLES30.glGetAttribLocation(program, "aPosition");
            int texCoord = GLES30.glGetAttribLocation(program, "aTexCoord");
            vertices.position(0);
            GLES30.glEnableVertexAttribArray(position);
            GLES30.glVertexAttribPointer(position, 2, GLES30.GL_FLOAT, false, 4 * Float.BYTES, vertices);
            vertices.position(2);
            GLES30.glEnableVertexAttribArray(texCoord);
            GLES30.glVertexAttribPointer(texCoord, 2, GLES30.GL_FLOAT, false, 4 * Float.BYTES, vertices);
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0);
            GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, cameraTextureId);
            GLES30.glUniform1i(GLES30.glGetUniformLocation(program, "uCamera"), 0);
            GLES30.glActiveTexture(GLES30.GL_TEXTURE1);
            GLES30.glBindTexture(GLES30.GL_TEXTURE_3D, lutTextureId);
            GLES30.glUniform1i(GLES30.glGetUniformLocation(program, "uLut"), 1);
            GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(program, "uTextureTransform"), 1, false, textureTransform, 0);
            GLES30.glUniform1i(GLES30.glGetUniformLocation(program, "uRotationDegrees"), rotationDegrees);
            GLES30.glUniform1i(GLES30.glGetUniformLocation(program, "uFrontCameraLandscapeCorrection"), correctFrontLandscape ? 1 : 0);
            GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4);
            GLES30.glDisableVertexAttribArray(position);
            GLES30.glDisableVertexAttribArray(texCoord);
        }
    }

    private static int createProgram(String vertexSource, String fragmentSource) {
        int vertex = compileShader(GLES30.GL_VERTEX_SHADER, vertexSource);
        int fragment = compileShader(GLES30.GL_FRAGMENT_SHADER, fragmentSource);
        int program = GLES30.glCreateProgram();
        GLES30.glAttachShader(program, vertex);
        GLES30.glAttachShader(program, fragment);
        GLES30.glLinkProgram(program);
        int[] linked = new int[1];
        GLES30.glGetProgramiv(program, GLES30.GL_LINK_STATUS, linked, 0);
        if( linked[0] == 0 ) {
            String message = GLES30.glGetProgramInfoLog(program);
            GLES30.glDeleteProgram(program);
            throw new IllegalStateException("Unable to link LUT preview shader: " + message);
        }
        GLES30.glDeleteShader(vertex);
        GLES30.glDeleteShader(fragment);
        return program;
    }

    private static int compileShader(int type, String source) {
        int shader = GLES30.glCreateShader(type);
        GLES30.glShaderSource(shader, source);
        GLES30.glCompileShader(shader);
        int[] compiled = new int[1];
        GLES30.glGetShaderiv(shader, GLES30.GL_COMPILE_STATUS, compiled, 0);
        if( compiled[0] == 0 ) {
            String message = GLES30.glGetShaderInfoLog(shader);
            GLES30.glDeleteShader(shader);
            throw new IllegalStateException("Unable to compile LUT preview shader: " + message);
        }
        return shader;
    }

    private static final String VERTEX_SHADER = "#version 300 es\n" +
            "in vec2 aPosition;\n" +
            "in vec2 aTexCoord;\n" +
            "out vec2 vTexCoord;\n" +
            "void main() { gl_Position = vec4(aPosition, 0.0, 1.0); vTexCoord = aTexCoord; }\n";

    private static final String FRAGMENT_SHADER = "#version 300 es\n" +
            "#extension GL_OES_EGL_image_external_essl3 : require\n" +
            "precision mediump float;\n" +
            "precision highp sampler3D;\n" +
            "uniform samplerExternalOES uCamera;\n" +
            "uniform sampler3D uLut;\n" +
            "uniform mat4 uTextureTransform;\n" +
            "uniform int uRotationDegrees;\n" +
            "uniform int uFrontCameraLandscapeCorrection;\n" +
            "in vec2 vTexCoord;\n" +
            "out vec4 outColor;\n" +
            "void main() {\n" +
            "  vec2 coordinate = (uTextureTransform * vec4(vTexCoord, 0.0, 1.0)).xy;\n" +
            "  if (uRotationDegrees == 90) coordinate = vec2(1.0 - coordinate.y, coordinate.x);\n" +
            "  else if (uRotationDegrees == 180) coordinate = vec2(1.0 - coordinate.x, 1.0 - coordinate.y);\n" +
            "  else if (uRotationDegrees == 270) coordinate = vec2(coordinate.y, 1.0 - coordinate.x);\n" +
            "  if (uFrontCameraLandscapeCorrection == 1) coordinate = vec2(1.0 - coordinate.x, 1.0 - coordinate.y);\n" +
            "  vec3 source = texture(uCamera, coordinate).rgb;\n" +
            "  vec3 graded = texture(uLut, vec3(source.b, source.g, source.r)).rgb;\n" +
            "  outColor = vec4(graded, 1.0);\n" +
            "}\n";
}
