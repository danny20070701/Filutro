package net.sourceforge.opencamera;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.preference.PreferenceManager;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/** Persists the active LUT and applies it immediately before the final JPEG is written. */
public final class FilutroLutStore {
    private static final String SELECTED_LUT_KEY = "filutro_selected_lut";
    private static final String IMPORT_PREFIX = "import-";
    private static final String IMPORT_NAME_PREFIX = "filutro_imported_lut_name_";

    private final Context context;
    private final SharedPreferences preferences;
    private final File directory;

    public FilutroLutStore(Context context) {
        this.context = context.getApplicationContext();
        this.preferences = PreferenceManager.getDefaultSharedPreferences(context);
        this.directory = new File(this.context.getFilesDir(), "luts");
    }

    public String selectedId() {
        return preferences.getString(SELECTED_LUT_KEY, FilutroLutPresets.NEUTRAL);
    }

    /** Includes built-ins and every validated .cube file previously imported by the user. */
    public List<FilutroLutPresets.Entry> entries() {
        List<FilutroLutPresets.Entry> entries = new ArrayList<>(FilutroLutPresets.entries());
        File[] files = directory.listFiles((dir, name) -> name.startsWith(IMPORT_PREFIX) && name.endsWith(".cube"));
        if( files == null ) {
            return entries;
        }
        Arrays.sort(files, Comparator.comparingLong(File::lastModified).reversed());
        for(File file : files) {
            String filename = file.getName();
            String id = filename.substring(0, filename.length() - ".cube".length());
            entries.add(new FilutroLutPresets.Entry(id, preferences.getString(IMPORT_NAME_PREFIX + id, "Imported LUT")));
        }
        return entries;
    }

    public void select(String id) {
        if( id == null || id.isEmpty() ) {
            id = FilutroLutPresets.NEUTRAL;
        }
        preferences.edit().putString(SELECTED_LUT_KEY, id).apply();
    }

    public String importCube(Uri uri) throws IOException {
        String source;
        try(InputStream input = context.getContentResolver().openInputStream(uri)) {
            if( input == null ) {
                throw new IOException("Unable to read LUT");
            }
            source = readUtf8(input);
        }
        FilutroCubeLut.parse(source); // validate before committing a file
        directory.mkdirs();
        String id = IMPORT_PREFIX + UUID.randomUUID();
        try(FileOutputStream output = new FileOutputStream(new File(directory, id + ".cube"))) {
            output.write(source.getBytes(StandardCharsets.UTF_8));
        }
        preferences.edit().putString(IMPORT_NAME_PREFIX + id, displayName(uri)).apply();
        select(id);
        return id;
    }

    private static String displayName(Uri uri) {
        String name = uri.getLastPathSegment();
        if( name == null || name.isEmpty() ) {
            return "Imported LUT";
        }
        int separator = Math.max(name.lastIndexOf('/'), name.lastIndexOf(':'));
        if( separator >= 0 && separator + 1 < name.length() ) {
            name = name.substring(separator + 1);
        }
        if( name.toLowerCase().endsWith(".cube") ) {
            name = name.substring(0, name.length() - ".cube".length());
        }
        return name.isEmpty() ? "Imported LUT" : name;
    }

    public Bitmap apply(byte[] jpegData, Bitmap bitmap) throws IOException {
        FilutroCubeLut lut = activeLut();
        if( lut == null ) {
            return bitmap;
        }
        if( bitmap == null ) {
            bitmap = ImageUtils.loadBitmapWithRotation(jpegData, true);
        }
        if( bitmap == null ) {
            throw new IOException("Unable to decode photo for LUT processing");
        }
        if( !bitmap.isMutable() ) {
            Bitmap copy = bitmap.copy(Bitmap.Config.ARGB_8888, true);
            bitmap.recycle();
            bitmap = copy;
        }
        int[] pixels = new int[bitmap.getWidth()];
        for(int y = 0; y < bitmap.getHeight(); y++) {
            bitmap.getPixels(pixels, 0, pixels.length, 0, y, pixels.length, 1);
            for(int x = 0; x < pixels.length; x++) {
                pixels[x] = lut.apply(pixels[x]);
            }
            bitmap.setPixels(pixels, 0, pixels.length, 0, y, pixels.length, 1);
        }
        return bitmap;
    }

    /** Returns a concrete LUT for GPU preview, including an identity LUT for Neutral. */
    public FilutroCubeLut selectedLut() throws IOException {
        FilutroCubeLut lut = activeLut();
        return lut != null ? lut : FilutroLutPresets.forId(FilutroLutPresets.NEUTRAL);
    }

    private FilutroCubeLut activeLut() throws IOException {
        String id = selectedId();
        if( FilutroLutPresets.NEUTRAL.equals(id) ) {
            return null;
        }
        for(FilutroLutPresets.Entry entry : FilutroLutPresets.entries()) {
            if( entry.id.equals(id) ) {
                return FilutroLutPresets.forId(id);
            }
        }
        if( !id.startsWith(IMPORT_PREFIX) ) {
            return null;
        }
        File cube = new File(directory, id + ".cube");
        if( !cube.isFile() ) {
            return null;
        }
        try(FileInputStream input = new FileInputStream(cube)) {
            return FilutroCubeLut.parse(readUtf8(input));
        }
    }

    private static String readUtf8(InputStream input) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        byte[] buffer = new byte[8 * 1024];
        int count;
        while( (count = input.read(buffer)) != -1 ) {
            bytes.write(buffer, 0, count);
        }
        return bytes.toString(StandardCharsets.UTF_8.name());
    }
}
