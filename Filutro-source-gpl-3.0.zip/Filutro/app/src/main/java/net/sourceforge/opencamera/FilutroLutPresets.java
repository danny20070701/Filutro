package net.sourceforge.opencamera;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Small, deterministic built-in looks. Imported .cube files use the same sampler. */
public final class FilutroLutPresets {
    public static final String NEUTRAL = "neutral";
    public static final String WARM_FILM = "warm-film";
    public static final String MONO_CONTRAST = "mono-contrast";

    public static final class Entry {
        public final String id;
        public final String name;

        Entry(String id, String name) {
            this.id = id;
            this.name = name;
        }
    }

    private static final List<Entry> ENTRIES;
    private static final Map<String, FilutroCubeLut> CACHE = new HashMap<>();
    private static final LookSpec[] LOOKS = {
            new LookSpec("golden-negative", "Golden Negative", 0.88f, 0.96f, 1.08f, 1.01f, 0.88f, 0.025f),
            new LookSpec("soft-negative", "Soft Negative", 0.78f, 0.84f, 1.04f, 1.00f, 0.93f, 0.06f),
            new LookSpec("amber-print", "Amber Print", 0.92f, 1.04f, 1.12f, 1.01f, 0.82f, 0.01f),
            new LookSpec("rose-print", "Rose Print", 0.82f, 0.94f, 1.10f, 0.96f, 0.96f, 0.035f),
            new LookSpec("pastel-negative", "Pastel Negative", 0.65f, 0.80f, 1.04f, 1.02f, 1.02f, 0.09f),
            new LookSpec("rangefinder-street", "Rangefinder Street", 0.92f, 1.14f, 1.05f, 1.02f, 0.93f, 0.0f),
            new LookSpec("silver-street", "Silver Street", 0.72f, 1.16f, 1.00f, 1.02f, 1.05f, 0.0f),
            new LookSpec("clear-day", "Clear Day", 1.10f, 1.06f, 1.02f, 1.05f, 1.08f, 0.0f),
            new LookSpec("coastal-blue", "Coastal Blue", 0.90f, 1.02f, 0.91f, 1.00f, 1.15f, 0.015f),
            new LookSpec("cobalt-cinema", "Cobalt Cinema", 0.84f, 1.18f, 0.88f, 1.00f, 1.16f, 0.0f),
            new LookSpec("teal-amber", "Teal Amber", 1.05f, 1.12f, 1.10f, 1.01f, 0.86f, 0.0f),
            new LookSpec("sunset-cinema", "Sunset Cinema", 1.08f, 1.10f, 1.16f, 0.98f, 0.83f, 0.0f),
            new LookSpec("desert-cinema", "Desert Cinema", 0.76f, 1.02f, 1.13f, 1.03f, 0.82f, 0.025f),
            new LookSpec("forest-cinema", "Forest Cinema", 0.90f, 1.08f, 0.91f, 1.11f, 0.90f, 0.0f),
            new LookSpec("night-cyan", "Night Cyan", 0.80f, 1.18f, 0.82f, 1.02f, 1.18f, 0.0f),
            new LookSpec("night-sodium", "Night Sodium", 0.94f, 1.14f, 1.18f, 0.98f, 0.72f, 0.0f),
            new LookSpec("vivid-slide", "Vivid Slide", 1.30f, 1.16f, 1.10f, 1.04f, 1.06f, 0.0f),
            new LookSpec("cool-slide", "Cool Slide", 1.18f, 1.13f, 0.91f, 1.00f, 1.16f, 0.0f),
            new LookSpec("warm-slide", "Warm Slide", 1.16f, 1.10f, 1.16f, 1.02f, 0.85f, 0.0f),
            new LookSpec("emerald-slide", "Emerald Slide", 1.14f, 1.12f, 0.90f, 1.16f, 0.91f, 0.0f),
            new LookSpec("faded-summer", "Faded Summer", 0.70f, 0.78f, 1.08f, 1.03f, 0.91f, 0.10f),
            new LookSpec("faded-winter", "Faded Winter", 0.62f, 0.82f, 0.93f, 1.02f, 1.12f, 0.08f),
            new LookSpec("dusty-rose", "Dusty Rose", 0.68f, 0.90f, 1.11f, 0.95f, 0.98f, 0.055f),
            new LookSpec("muted-olive", "Muted Olive", 0.58f, 0.96f, 0.95f, 1.07f, 0.86f, 0.035f),
            new LookSpec("clean-portrait", "Clean Portrait", 0.86f, 0.92f, 1.06f, 1.01f, 0.96f, 0.035f),
            new LookSpec("pearl-portrait", "Pearl Portrait", 0.68f, 0.82f, 1.04f, 1.02f, 1.04f, 0.075f),
            new LookSpec("high-key", "High Key", 0.74f, 0.74f, 1.03f, 1.03f, 1.03f, 0.14f),
            new LookSpec("low-key", "Low Key", 0.84f, 1.28f, 0.96f, 0.98f, 1.02f, -0.06f),
            new LookSpec("graphite", "Graphite", 0.12f, 1.22f, 1.00f, 1.00f, 1.00f, 0.0f),
            new LookSpec("warm-monochrome", "Warm Monochrome", 0.04f, 1.10f, 1.14f, 1.03f, 0.82f, 0.0f),
            new LookSpec("cool-monochrome", "Cool Monochrome", 0.04f, 1.10f, 0.82f, 0.96f, 1.18f, 0.0f),
            new LookSpec("infrared-garden", "Infrared Garden", 1.20f, 1.04f, 1.18f, 0.94f, 1.06f, 0.0f),
            new LookSpec("electric-violet", "Electric Violet", 1.20f, 1.14f, 1.11f, 0.86f, 1.18f, 0.0f),
            new LookSpec("red-room", "Red Room", 0.98f, 1.17f, 1.25f, 0.85f, 0.86f, 0.0f),
            new LookSpec("cyanotype", "Cyanotype", 0.52f, 1.08f, 0.72f, 1.00f, 1.24f, 0.0f),
            new LookSpec("sepia-paper", "Sepia Paper", 0.42f, 0.96f, 1.18f, 1.05f, 0.74f, 0.025f),
            new LookSpec("chrome-pop", "Chrome Pop", 1.08f, 1.20f, 1.05f, 1.04f, 1.05f, 0.0f),
    };

    static {
        List<Entry> entries = new ArrayList<>();
        entries.add(new Entry(NEUTRAL, "Neutral"));
        entries.add(new Entry(WARM_FILM, "Warm Film"));
        entries.add(new Entry(MONO_CONTRAST, "Mono Contrast"));
        for(LookSpec look : LOOKS) {
            entries.add(new Entry(look.id, look.name));
        }
        ENTRIES = Collections.unmodifiableList(entries);
    }

    private FilutroLutPresets() {
    }

    public static List<Entry> entries() {
        return ENTRIES;
    }

    public static synchronized FilutroCubeLut forId(String id) {
        FilutroCubeLut cached = CACHE.get(id);
        if( cached != null ) {
            return cached;
        }
        FilutroCubeLut lut;
        if( WARM_FILM.equals(id) ) {
            lut = generated((red, green, blue) -> new float[] {
                    clamp(1.08f * red + 0.03f),
                    clamp(0.98f * green + 0.01f),
                    clamp(0.88f * blue)
            });
        }
        else if( MONO_CONTRAST.equals(id) ) {
            lut = generated((red, green, blue) -> {
                float luma = clamp((0.2126f * red + 0.7152f * green + 0.0722f * blue - 0.5f) * 1.18f + 0.5f);
                return new float[] {luma, luma, luma};
            });
        }
        else {
            LookSpec look = findLook(id);
            if( look == null ) {
                lut = generated((red, green, blue) -> new float[] {red, green, blue});
            }
            else {
                lut = generated((red, green, blue) -> transform(look, red, green, blue));
            }
        }
        CACHE.put(id, lut);
        return lut;
    }

    private static FilutroCubeLut generated(Transform transform) {
        final int size = 16;
        StringBuilder cube = new StringBuilder("LUT_3D_SIZE 16\n");
        for(int redIndex = 0; redIndex < size; redIndex++) {
            for(int greenIndex = 0; greenIndex < size; greenIndex++) {
                for(int blueIndex = 0; blueIndex < size; blueIndex++) {
                    float[] rgb = transform.apply(redIndex / 15.0f, greenIndex / 15.0f, blueIndex / 15.0f);
                    cube.append(rgb[0]).append(' ').append(rgb[1]).append(' ').append(rgb[2]).append('\n');
                }
            }
        }
        return FilutroCubeLut.parse(cube.toString());
    }

    private static float clamp(float value) {
        return Math.max(0.0f, Math.min(1.0f, value));
    }

    private static LookSpec findLook(String id) {
        for(LookSpec look : LOOKS) {
            if( look.id.equals(id) ) {
                return look;
            }
        }
        return null;
    }

    private static float[] transform(LookSpec look, float red, float green, float blue) {
        float luma = 0.2126f * red + 0.7152f * green + 0.0722f * blue;
        return new float[] {
                channel(look, red, luma, look.red),
                channel(look, green, luma, look.green),
                channel(look, blue, luma, look.blue),
        };
    }

    private static float channel(LookSpec look, float value, float luma, float gain) {
        float saturated = luma + (value - luma) * look.saturation;
        return clamp(((saturated - 0.5f) * look.contrast + 0.5f) * gain + look.lift);
    }

    private static final class LookSpec {
        final String id;
        final String name;
        final float saturation;
        final float contrast;
        final float red;
        final float green;
        final float blue;
        final float lift;

        LookSpec(String id, String name, float saturation, float contrast, float red, float green, float blue, float lift) {
            this.id = id;
            this.name = name;
            this.saturation = saturation;
            this.contrast = contrast;
            this.red = red;
            this.green = green;
            this.blue = blue;
            this.lift = lift;
        }
    }

    private interface Transform {
        float[] apply(float red, float green, float blue);
    }
}
