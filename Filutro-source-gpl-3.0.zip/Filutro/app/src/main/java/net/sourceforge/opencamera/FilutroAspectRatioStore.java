package net.sourceforge.opencamera;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

final class FilutroAspectRatioStore {
    private static final String KEY = "filutro_aspect_ratio";
    private final SharedPreferences preferences;

    FilutroAspectRatioStore(Context context) {
        preferences = PreferenceManager.getDefaultSharedPreferences(context);
    }

    FilutroAspectRatio get() {
        try {
            return FilutroAspectRatio.valueOf(preferences.getString(KEY, FilutroAspectRatio.ORIGINAL.name()));
        }
        catch(IllegalArgumentException e) {
            return FilutroAspectRatio.ORIGINAL;
        }
    }

    void set(FilutroAspectRatio ratio) {
        preferences.edit().putString(KEY, ratio.name()).apply();
    }
}
