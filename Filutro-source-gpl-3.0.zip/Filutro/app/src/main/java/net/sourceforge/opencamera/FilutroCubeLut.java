package net.sourceforge.opencamera;

import java.util.ArrayList;
import java.util.List;

/** Compact `.cube` 3D LUT parser and trilinear sampler shared by preview and photo output. */
public final class FilutroCubeLut {
    private final int size;
    private final float[] rgb;

    private FilutroCubeLut(int size, float[] rgb) {
        this.size = size;
        this.rgb = rgb;
    }

    public static FilutroCubeLut parse(String cube) {
        int size = 0;
        List<Float> values = new ArrayList<>();
        for(String rawLine : cube.split("\\r?\\n")) {
            String line = rawLine.trim();
            if( line.isEmpty() || line.startsWith("#") || line.startsWith("TITLE") || line.startsWith("DOMAIN_") ) {
                continue;
            }
            if( line.startsWith("LUT_1D_SIZE") ) {
                throw new IllegalArgumentException("Filutro requires a 3D .cube LUT");
            }
            if( line.startsWith("LUT_3D_SIZE") ) {
                String[] parts = line.split("\\s+");
                if( parts.length != 2 ) {
                    throw new IllegalArgumentException("Invalid LUT_3D_SIZE");
                }
                size = Integer.parseInt(parts[1]);
                if( size < 2 || size > 64 ) {
                    throw new IllegalArgumentException("LUT_3D_SIZE must be between 2 and 64");
                }
                continue;
            }
            String[] parts = line.split("\\s+");
            if( parts.length != 3 ) {
                throw new IllegalArgumentException("Invalid LUT color row");
            }
            for(String part : parts) {
                float value = Float.parseFloat(part);
                if( !Float.isFinite(value) ) {
                    throw new IllegalArgumentException("LUT colors must be finite");
                }
                values.add(Math.max(0.0f, Math.min(1.0f, value)));
            }
        }
        int expected = size * size * size * 3;
        if( size == 0 || values.size() != expected ) {
            throw new IllegalArgumentException("LUT data does not match LUT_3D_SIZE");
        }
        float[] rgb = new float[expected];
        for(int i = 0; i < expected; i++) {
            rgb[i] = values.get(i);
        }
        return new FilutroCubeLut(size, rgb);
    }

    public int apply(int argb) {
        float red = ((argb >> 16) & 0xFF) / 255.0f;
        float green = ((argb >> 8) & 0xFF) / 255.0f;
        float blue = (argb & 0xFF) / 255.0f;
        int outputRed = Math.round(sample(red, green, blue, 0) * 255.0f);
        int outputGreen = Math.round(sample(red, green, blue, 1) * 255.0f);
        int outputBlue = Math.round(sample(red, green, blue, 2) * 255.0f);
        return (argb & 0xFF000000) | (outputRed << 16) | (outputGreen << 8) | outputBlue;
    }

    /** Size of each axis in the 3D lookup texture. */
    public int size() {
        return size;
    }

    /** RGB bytes in .cube order for an OpenGL ES 3D texture. */
    public byte[] toRgbBytes() {
        byte[] bytes = new byte[rgb.length];
        for(int i = 0; i < rgb.length; i++) {
            bytes[i] = (byte)Math.round(clamp(rgb[i]) * 255.0f);
        }
        return bytes;
    }

    private float sample(float red, float green, float blue, int channel) {
        float scale = size - 1.0f;
        float scaledRed = clamp(red) * scale;
        float scaledGreen = clamp(green) * scale;
        float scaledBlue = clamp(blue) * scale;
        int red0 = (int)scaledRed;
        int green0 = (int)scaledGreen;
        int blue0 = (int)scaledBlue;
        int red1 = Math.min(red0 + 1, size - 1);
        int green1 = Math.min(green0 + 1, size - 1);
        int blue1 = Math.min(blue0 + 1, size - 1);
        float redAmount = scaledRed - red0;
        float greenAmount = scaledGreen - green0;
        float blueAmount = scaledBlue - blue0;
        float c00 = mix(value(red0, green0, blue0, channel), value(red1, green0, blue0, channel), redAmount);
        float c01 = mix(value(red0, green0, blue1, channel), value(red1, green0, blue1, channel), redAmount);
        float c10 = mix(value(red0, green1, blue0, channel), value(red1, green1, blue0, channel), redAmount);
        float c11 = mix(value(red0, green1, blue1, channel), value(red1, green1, blue1, channel), redAmount);
        return mix(mix(c00, c10, greenAmount), mix(c01, c11, greenAmount), blueAmount);
    }

    private float value(int red, int green, int blue, int channel) {
        return rgb[(((red * size + green) * size + blue) * 3) + channel];
    }

    private static float mix(float low, float high, float amount) {
        return low + (high - low) * amount;
    }

    private static float clamp(float value) {
        return Math.max(0.0f, Math.min(1.0f, value));
    }
}
