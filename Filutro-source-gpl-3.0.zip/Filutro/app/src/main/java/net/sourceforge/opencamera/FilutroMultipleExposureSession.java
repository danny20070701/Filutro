package net.sourceforge.opencamera;

import java.util.ArrayList;
import java.util.List;

/** Collects the separate shutter presses that make up one multiple exposure photo. */
final class FilutroMultipleExposureSession {
    private final int frameCount;
    private final List<byte[]> frames = new ArrayList<>();

    FilutroMultipleExposureSession(int frameCount) {
        if( frameCount < 2 || frameCount > 4 ) {
            throw new IllegalArgumentException("Multiple exposure count must be from 2 to 4");
        }
        this.frameCount = frameCount;
    }

    synchronized List<byte[]> add(byte[] frame) {
        if( frame == null || frame.length == 0 ) {
            throw new IllegalArgumentException("Frame must contain JPEG data");
        }
        frames.add(frame);
        if( frames.size() < frameCount ) {
            return null;
        }
        List<byte[]> complete = new ArrayList<>(frames);
        frames.clear();
        return complete;
    }

    synchronized int capturedCount() {
        return frames.size();
    }

    /** Returns the incomplete exposure stack for rendering live composition guidance. */
    synchronized List<byte[]> pendingFrames() {
        return new ArrayList<>(frames);
    }

    synchronized void clear() {
        frames.clear();
    }
}
