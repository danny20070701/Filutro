package net.sourceforge.opencamera;

/** Compact grid catalog for the Filutro control, rendered by Open Camera's DrawPreview. */
final class FilutroGrid {
    static final class Entry {
        final String label;
        final String value;

        Entry(String label, String value) {
            this.label = label;
            this.value = value;
        }
    }

    private static final Entry[] ENTRIES = {
            new Entry("Off", "preference_grid_none"),
            new Entry("3 x 3", "preference_grid_3x3"),
            new Entry("Phi 3 x 3", "preference_grid_phi_3x3"),
            new Entry("4 x 2", "preference_grid_4x2"),
            new Entry("Crosshair", "preference_grid_crosshair"),
            new Entry("Golden spiral 1", "preference_grid_golden_spiral_right"),
            new Entry("Golden spiral 2", "preference_grid_golden_spiral_left"),
            new Entry("Golden spiral 3", "preference_grid_golden_spiral_upside_down_right"),
            new Entry("Golden spiral 4", "preference_grid_golden_spiral_upside_down_left"),
            new Entry("Golden triangle 1", "preference_grid_golden_triangle_1"),
            new Entry("Golden triangle 2", "preference_grid_golden_triangle_2"),
            new Entry("Diagonals", "preference_grid_diagonals")
    };

    private FilutroGrid() {
    }

    static Entry[] entries() {
        return ENTRIES.clone();
    }
}
