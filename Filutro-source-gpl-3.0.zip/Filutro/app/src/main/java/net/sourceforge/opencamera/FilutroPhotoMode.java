package net.sourceforge.opencamera;

/** Preference values used by Filutro's compact photo-only mode controls. */
public final class FilutroPhotoMode {
    public static final String STANDARD = "preference_photo_mode_std";
    public static final String HDR = "preference_photo_mode_hdr";

    private FilutroPhotoMode() {
    }

    public static String toggleHdr(String currentMode, boolean supportsHdr) {
        if( HDR.equals(currentMode) || !supportsHdr ) {
            return STANDARD;
        }
        return HDR;
    }
}
