package net.sourceforge.opencamera;

import android.content.SharedPreferences;

/** Preference contract for Filutro's sequential multiple exposure capture. */
final class FilutroMultipleExposureMode {
    static final String KEY = "filutro_multiple_exposure_frames";

    private FilutroMultipleExposureMode() {
    }

    static int get(SharedPreferences preferences) {
        return parse(preferences.getString(KEY, "off"));
    }

    static void set(SharedPreferences preferences, int frameCount) {
        preferences.edit().putString(KEY, frameCount == 0 ? "off" : Integer.toString(frameCount)).apply();
    }

    static int parse(String value) {
        if( "2".equals(value) ) {
            return 2;
        }
        if( "3".equals(value) ) {
            return 3;
        }
        if( "4".equals(value) ) {
            return 4;
        }
        return 0;
    }
}
