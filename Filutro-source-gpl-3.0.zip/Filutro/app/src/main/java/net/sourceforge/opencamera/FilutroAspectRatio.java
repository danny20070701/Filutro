package net.sourceforge.opencamera;

/** Output aspect ratios available in Filutro's photo-only capture workflow. */
public enum FilutroAspectRatio {
    ORIGINAL("Original", 0.0),
    SQUARE("1:1", 1.0),
    FOUR_THREE("4:3", 4.0 / 3.0),
    THREE_TWO("3:2", 3.0 / 2.0),
    WIDESCREEN("16:9", 16.0 / 9.0),
    CINEMA_185("1.85:1", 1.85),
    CINEMA_239("2.39:1", 2.39);

    public final String label;
    private final double landscapeRatio;

    FilutroAspectRatio(String label, double landscapeRatio) {
        this.label = label;
        this.landscapeRatio = landscapeRatio;
    }

    public Crop centerCrop(int width, int height) {
        if( this == ORIGINAL || width <= 0 || height <= 0 ) {
            return new Crop(0, 0, width, height);
        }
        double target = width >= height ? landscapeRatio : 1.0 / landscapeRatio;
        double current = (double)width / height;
        int cropWidth = width;
        int cropHeight = height;
        if( current > target ) {
            cropWidth = Math.max(1, (int)(height * target));
        }
        else if( current < target ) {
            cropHeight = Math.max(1, (int)(width / target));
        }
        return new Crop((width - cropWidth) / 2, (height - cropHeight) / 2, cropWidth, cropHeight);
    }

    /** Open Camera's preview crop-guide identifier for this exact output choice. */
    public String cropGuidePreference() {
        switch( this ) {
            case SQUARE:
                return "crop_guide_1";
            case FOUR_THREE:
                return "crop_guide_1.33";
            case THREE_TWO:
                return "crop_guide_1.5";
            case WIDESCREEN:
                return "crop_guide_1.78";
            case CINEMA_185:
                return "crop_guide_1.85";
            case CINEMA_239:
                // Open Camera's native 2.4:1 guide is within 0.4% of the Filutro output crop.
                return "crop_guide_2.4";
            case ORIGINAL:
            default:
                return "crop_guide_none";
        }
    }

    public static final class Crop {
        public final int left;
        public final int top;
        public final int width;
        public final int height;

        Crop(int left, int top, int width, int height) {
            this.left = left;
            this.top = top;
            this.width = width;
            this.height = height;
        }
    }
}
