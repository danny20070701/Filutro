package net.sourceforge.opencamera;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class FilutroAspectRatioTest {
    @Test
    public void ratiosExposeMatchingPreviewCropGuides() {
        assertEquals("crop_guide_none", FilutroAspectRatio.ORIGINAL.cropGuidePreference());
        assertEquals("crop_guide_1", FilutroAspectRatio.SQUARE.cropGuidePreference());
        assertEquals("crop_guide_1.33", FilutroAspectRatio.FOUR_THREE.cropGuidePreference());
        assertEquals("crop_guide_1.5", FilutroAspectRatio.THREE_TWO.cropGuidePreference());
        assertEquals("crop_guide_1.78", FilutroAspectRatio.WIDESCREEN.cropGuidePreference());
        assertEquals("crop_guide_1.85", FilutroAspectRatio.CINEMA_185.cropGuidePreference());
        assertEquals("crop_guide_2.4", FilutroAspectRatio.CINEMA_239.cropGuidePreference());
    }

    @Test
    public void cinematicCropPreservesPortraitOrientation() {
        FilutroAspectRatio.Crop crop = FilutroAspectRatio.CINEMA_239.centerCrop(3000, 4000);

        assertEquals(663, crop.left);
        assertEquals(0, crop.top);
        assertEquals(1673, crop.width);
        assertEquals(4000, crop.height);
    }
}
