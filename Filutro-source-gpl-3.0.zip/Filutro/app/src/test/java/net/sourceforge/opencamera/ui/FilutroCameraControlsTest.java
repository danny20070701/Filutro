package net.sourceforge.opencamera.ui;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

public class FilutroCameraControlsTest {
    @Test
    public void cameraLayoutUsesDedicatedLargeFilutroControlRail() throws IOException {
        File layout = new File("src/main/res/layout/activity_main.xml");
        if( !layout.isFile() ) {
            layout = new File("app/src/main/res/layout/activity_main.xml");
        }
        String xml = new String(Files.readAllBytes(layout.toPath()), StandardCharsets.UTF_8);

        assertTrue("Filutro controls need their own rail", xml.contains("@+id/filutro_top_controls"));
        assertTrue("Filutro controls need large touch targets", xml.contains("android:layout_height=\"48dp\""));
        assertTrue("Filutro icons should use the full large touch target", xml.contains("android:padding=\"0dp\""));
        int multipleExposure = xml.indexOf("@+id/filutro_multiple_exposure");
        assertTrue("Multiple exposure icon needs an optical baseline correction", xml.indexOf("ic_filutro_multiple_exposure_aligned", multipleExposure) > multipleExposure);
    }

    @Test
    public void settingsDoNotExposeVideoControls() throws IOException {
        File root = new File("src/main/res/xml");
        if( !root.isDirectory() ) {
            root = new File("app/src/main/res/xml");
        }
        String settings = new String(Files.readAllBytes(new File(root, "preferences.xml").toPath()), StandardCharsets.UTF_8);
        String controls = new String(Files.readAllBytes(new File(root, "preferences_sub_camera_controls_more.xml").toPath()), StandardCharsets.UTF_8);
        String preview = new String(Files.readAllBytes(new File(root, "preferences_sub_preview.xml").toPath()), StandardCharsets.UTF_8);
        String remote = new String(Files.readAllBytes(new File(root, "preferences_sub_remote_ctrl.xml").toPath()), StandardCharsets.UTF_8);
        String photo = new String(Files.readAllBytes(new File(root, "preferences_sub_photo.xml").toPath()), StandardCharsets.UTF_8);

        assertTrue("Video settings must not be reachable", !settings.contains("preference_screen_video_settings"));
        assertTrue("Photo-only app must not show a video filename prefix", !controls.contains("preference_save_video_prefix"));
        assertTrue("Preview settings must not contain a video meter", !preview.contains("preference_show_video_max_amp"));
        assertTrue("Remote controls must not contain a video mode", !remote.contains("preference_remote_video_mode"));
        assertTrue("Photo settings must not contain photo-while-recording", !photo.contains("preference_camera2_photo_video_recording"));
    }

    @Test
    public void topControlRailUsesOneUnclippedRow() throws IOException {
        File layout = new File("src/main/res/layout/activity_main.xml");
        if( !layout.isFile() ) {
            layout = new File("app/src/main/res/layout/activity_main.xml");
        }
        String xml = new String(Files.readAllBytes(layout.toPath()), StandardCharsets.UTF_8);

        int controlRail = xml.indexOf("@+id/filutro_top_controls");
        assertTrue("Filutro controls should use one horizontal rail", xml.lastIndexOf("<HorizontalScrollView", controlRail) >= 0);
        assertTrue("The first seven controls should fill the rail without clipping", xml.indexOf("android:layout_width=\"56dp\"", controlRail) > controlRail);
        assertTrue("Top controls should have no artificial spacer", !xml.contains("@+id/filutro_controls_spacer"));
        assertTrue("Exposure controls should remain available after a horizontal swipe", xml.indexOf("@+id/exposure_lock", controlRail) > controlRail);
        assertTrue("Settings should follow exposure lock", xml.indexOf("@+id/settings", controlRail) > xml.indexOf("@+id/exposure_lock", controlRail));
    }

    @Test
    public void topControlsUseOpticalBaselineCorrections() throws IOException {
        File layout = new File("src/main/res/layout/activity_main.xml");
        if( !layout.isFile() ) {
            layout = new File("app/src/main/res/layout/activity_main.xml");
        }
        String xml = new String(Files.readAllBytes(layout.toPath()), StandardCharsets.UTF_8);
        String[] ids = {"popup", "filutro_hdr", "cycle_flash", "settings", "exposure", "exposure_lock"};
        for( String id : ids ) {
            int button = xml.indexOf("@+id/" + id);
            assertTrue(id + " should have an optical baseline correction", xml.indexOf("android:translationY=", button) > button);
        }
    }

    @Test
    public void previewAlwaysUsesThePhysicalDisplayOrientation() throws IOException {
        File root = new File("src/main");
        if( !root.isDirectory() ) {
            root = new File("app/src/main");
        }
        String applicationInterface = new String(Files.readAllBytes(new File(root, "java/net/sourceforge/opencamera/MyApplicationInterface.java").toPath()), StandardCharsets.UTF_8);
        String previewSettings = new String(Files.readAllBytes(new File(root, "res/xml/preferences_sub_preview.xml").toPath()), StandardCharsets.UTF_8);

        assertTrue("Filutro must not inherit Open Camera's 180-degree preview override", !applicationInterface.contains("RotatePreviewPreferenceKey"));
        assertTrue("Filutro settings must not offer a preview-flip control", !previewSettings.contains("preference_rotate_preview"));
    }

    @Test
    public void shutterFeedbackUsesBuiltInFilutroSounds() throws IOException {
        File root = new File("src/main");
        if( !root.isDirectory() ) {
            root = new File("app/src/main");
        }
        File raw = new File(root, "res/raw");
        for( int sound = 1; sound <= 5; sound++ ) {
            assertTrue("Built-in shutter sound " + sound + " is missing", new File(raw, "shutter_click_" + sound + ".mp3").isFile());
        }
        String mainActivity = new String(Files.readAllBytes(new File(root, "java/net/sourceforge/opencamera/MainActivity.java").toPath()), StandardCharsets.UTF_8);
        String applicationInterface = new String(Files.readAllBytes(new File(root, "java/net/sourceforge/opencamera/MyApplicationInterface.java").toPath()), StandardCharsets.UTF_8);
        String soundPool = new String(Files.readAllBytes(new File(root, "java/net/sourceforge/opencamera/SoundPoolManager.java").toPath()), StandardCharsets.UTF_8);
        assertTrue("Built-in shutter sound must be preloaded", mainActivity.contains("soundPoolManager.loadSound(R.raw.shutter_click_1)"));
        assertTrue("A capture must trigger the built-in shutter sound", applicationInterface.contains("playFilutroShutterSound()"));
        assertTrue("Filutro shutter sound should not depend on the device system-click volume", soundPool.contains("AudioAttributes.USAGE_ASSISTANCE_SONIFICATION"));
        assertTrue("Rapid continuous captures need enough sound streams to preserve each shutter click", soundPool.contains(".setMaxStreams(4)"));

        int captureStarted = applicationInterface.indexOf("public void onCaptureStarted()");
        int captureCompleted = applicationInterface.indexOf("public void onPictureCompleted()", captureStarted);
        int pictureTaken = applicationInterface.indexOf("public boolean onPictureTaken(byte [] data", captureCompleted);
        int multipleExposureFrame = applicationInterface.indexOf("private synchronized List<byte[]> addMultipleExposureFrame", pictureTaken);
        assertTrue("The shutter sound should be tied to every received JPEG, not only the first burst request", applicationInterface.indexOf("playFilutroShutterSound()", pictureTaken) < multipleExposureFrame);
        assertTrue("The shutter sound must not be limited to the first capture in a continuous burst", applicationInterface.indexOf("playFilutroShutterSound()", captureStarted) > captureCompleted);
    }

    @Test
    public void shutterSoundChoiceRemainsAvailableOnEveryDevice() throws IOException {
        File root = new File("src/main");
        if( !root.isDirectory() ) {
            root = new File("app/src/main");
        }
        String settings = new String(Files.readAllBytes(new File(root, "res/xml/preferences_sub_camera_controls_more.xml").toPath()), StandardCharsets.UTF_8);
        String arrays = new String(Files.readAllBytes(new File(root, "res/values/arrays.xml").toPath()), StandardCharsets.UTF_8);
        String settingsController = new String(Files.readAllBytes(new File(root, "java/net/sourceforge/opencamera/PreferenceSubCameraControlsMore.java").toPath()), StandardCharsets.UTF_8);
        String applicationInterface = new String(Files.readAllBytes(new File(root, "java/net/sourceforge/opencamera/MyApplicationInterface.java").toPath()), StandardCharsets.UTF_8);

        assertTrue("Filutro settings must expose a shutter sound chooser", settings.contains("android:key=\"preference_filutro_shutter_sound\""));
        assertTrue("The shutter sound chooser must provide built-in sound options", arrays.contains("preference_filutro_shutter_sound_entries"));
        assertTrue("The shutter sound chooser must provide stable option values", arrays.contains("preference_filutro_shutter_sound_values"));
        assertTrue("Custom shutter sounds must not be removed for devices with fixed system clicks", !settingsController.contains("removePreference(findPreference(\"preference_filutro_shutter_sound\"))"));
        assertTrue("The selected custom shutter sound must determine which built-in file plays", applicationInterface.contains("getFilutroShutterSoundResource()"));
    }

    @Test
    public void launchAnimationAndAttributionAreWired() throws IOException {
        File root = new File("src/main");
        if( !root.isDirectory() ) {
            root = new File("app/src/main");
        }
        String layout = new String(Files.readAllBytes(new File(root, "res/layout/activity_main.xml").toPath()), StandardCharsets.UTF_8);
        String mainActivity = new String(Files.readAllBytes(new File(root, "java/net/sourceforge/opencamera/MainActivity.java").toPath()), StandardCharsets.UTF_8);
        String preferenceFragment = new String(Files.readAllBytes(new File(root, "java/net/sourceforge/opencamera/MyPreferenceFragment.java").toPath()), StandardCharsets.UTF_8);
        String strings = new String(Files.readAllBytes(new File(root, "res/values/strings.xml").toPath()), StandardCharsets.UTF_8);

        assertTrue("Launch overlay must be the topmost Filutro view", layout.contains("@+id/filutro_launch_overlay"));
        assertTrue("Launch animation must be black", layout.contains("android:background=\"#000000\""));
        assertTrue("Launch animation must use the AI-created Filutro launcher mark", layout.contains("@mipmap/ic_launcher_foreground"));
        assertTrue("MainActivity must start the launch animation", mainActivity.contains("startFilutroLaunchAnimation()"));
        assertTrue("Launch animation must wait until the camera startup work has released the UI thread", mainActivity.contains("launchOverlay.post(new Runnable()"));
        assertTrue("Launch animation must remain visible for a full opening beat", mainActivity.contains("FILUTRO_LAUNCH_ANIMATION_DURATION_MS = 2000"));
        assertTrue("The launch overlay must stay opaque until it is removed", !mainActivity.contains("launchOverlay.animate()"));
        assertTrue("The overlay must be removed when the animation ends", mainActivity.contains("launchOverlay.setVisibility(View.GONE)"));
        assertTrue("Creator attribution must be a resource", strings.contains("name=\"filutro_creator_credit\""));
        assertTrue("Open Camera attribution must be a resource", strings.contains("name=\"filutro_open_camera_credit\""));
        assertTrue("About must credit PCIE / 班禪", preferenceFragment.contains("R.string.filutro_creator_credit"));
        assertTrue("About must disclose the Open Camera base", preferenceFragment.contains("R.string.filutro_open_camera_credit"));
    }

    @Test
    public void applicationNameIsFilutroInEveryLocale() throws IOException {
        File resources = new File("src/main/res");
        if( !resources.isDirectory() ) {
            resources = new File("app/src/main/res");
        }
        File[] resourceDirectories = resources.listFiles();
        assertTrue("Android resources directory must be readable", resourceDirectories != null);
        for( File resourceDirectory : resourceDirectories ) {
            if( !resourceDirectory.getName().startsWith("values") )
                continue;
            File strings = new File(resourceDirectory, "strings.xml");
            if( !strings.isFile() )
                continue;
            String contents = new String(Files.readAllBytes(strings.toPath()), StandardCharsets.UTF_8);
            assertTrue("App name must remain Filutro in " + resourceDirectory.getName(), contents.contains("<string name=\"app_name\">Filutro</string>"));
        }
    }

    @Test
    public void frontCameraSwitchRemainsAvailableForMultiCameraDevices() throws IOException {
        File root = new File("src/main");
        if( !root.isDirectory() ) {
            root = new File("app/src/main");
        }
        String layout = new String(Files.readAllBytes(new File(root, "res/layout/activity_main.xml").toPath()), StandardCharsets.UTF_8);
        String mainActivity = new String(Files.readAllBytes(new File(root, "java/net/sourceforge/opencamera/MainActivity.java").toPath()), StandardCharsets.UTF_8);
        String mainUi = new String(Files.readAllBytes(new File(root, "java/net/sourceforge/opencamera/ui/MainUI.java").toPath()), StandardCharsets.UTF_8);

        assertTrue("Front camera switch must exist", layout.contains("android:id=\"@+id/switch_camera\""));
        assertTrue("Camera setup must expose the switch for multi-camera devices", mainActivity.contains("switchCameraButton.setVisibility(n_cameras > 1 ? View.VISIBLE : View.GONE)"));
        assertTrue("Portrait layout must place the front camera switch above the shutter", mainUi.contains("switchParams.addRule(RelativeLayout.ABOVE, R.id.take_photo)"));
        assertTrue("Landscape layout must place the front camera switch beside the shutter", mainUi.contains("switchParams.addRule(RelativeLayout.LEFT_OF, R.id.take_photo)"));
    }

    @Test
    public void frontCameraLandscapePreviewHasAnUprightCorrection() throws IOException {
        File root = new File("src/main");
        if( !root.isDirectory() ) {
            root = new File("app/src/main");
        }
        String preview = new String(Files.readAllBytes(new File(root, "java/net/sourceforge/opencamera/preview/Preview.java").toPath()), StandardCharsets.UTF_8);
        String lutSurface = new String(Files.readAllBytes(new File(root, "java/net/sourceforge/opencamera/preview/camerasurface/FilutroLutSurface.java").toPath()), StandardCharsets.UTF_8);

        assertTrue("Only front camera landscape previews need the corrective turn", preview.contains("frontFacing && (displayRotationDegrees == 90 || displayRotationDegrees == 270)"));
        assertTrue("LUT renderer must receive the front landscape correction", lutSurface.contains("setCameraTransform(int displayRotationDegrees, boolean correctFrontLandscape)"));
        assertTrue("LUT shader must apply the upright correction", lutSurface.contains("uFrontCameraLandscapeCorrection"));
    }

    @Test
    public void portraitLayoutKeepsShutterRightAndZoomControlLarge() throws IOException {
        File root = new File("src/main");
        if( !root.isDirectory() ) {
            root = new File("app/src/main");
        }
        String layout = new String(Files.readAllBytes(new File(root, "res/layout/activity_main.xml").toPath()), StandardCharsets.UTF_8);
        String mainUi = new String(Files.readAllBytes(new File(root, "java/net/sourceforge/opencamera/ui/MainUI.java").toPath()), StandardCharsets.UTF_8);

        assertTrue("Zoom control should be large enough to adjust accurately", layout.contains("android:layout_width=\"220dp\""));
        assertTrue("Zoom control should have a broad track", layout.contains("android:layout_height=\"64dp\""));
        assertTrue("Shutter must be on the right", mainUi.contains("shutterParams.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, RelativeLayout.TRUE)"));
        assertTrue("Gallery must leave the shutter side clear", mainUi.contains("galleryParams.addRule(RelativeLayout.ALIGN_PARENT_LEFT, RelativeLayout.TRUE)"));
        assertTrue("Lens-picker button must stay hidden", mainUi.contains("switchMultiCameraButton.setVisibility(View.GONE)"));
        assertTrue("Camera switch should sit above the shutter", mainUi.contains("switchParams.addRule(RelativeLayout.ABOVE, R.id.take_photo)"));
        assertTrue("Camera switch should use the right edge", mainUi.contains("switchParams.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, RelativeLayout.TRUE)"));
        assertTrue("Filutro shooting controls must be laid out in every orientation", mainUi.contains("if( system_orientation_portrait ) {\n                layoutFilutroPortraitTopControls();\n                layoutFilutroPortraitControls();\n            }\n            else {\n                layoutFilutroLandscapeTopControls();\n                layoutFilutroLandscapeControls();\n            }"));
        assertTrue("Large zoom control must clear the gallery", mainUi.contains("zoom.setTranslationY(-zoomClearance)"));
        assertTrue("Zoom control should remain horizontal in portrait", mainUi.contains("zoom.setRotation(0.0f)"));
        assertTrue("Zoom control should sit above the shutter rail", mainUi.contains("zoomParams.addRule(RelativeLayout.ABOVE, R.id.take_photo)"));
        assertTrue("Zoom control should sit close to the shutter rail", mainUi.contains("int zoomClearance = (int)(55 * density + 0.5f)"));
        assertTrue("LUT should sit between the gallery and shutter", mainUi.contains("layoutFilutroBottomTool(R.id.filutro_lut"));
        assertTrue("Aspect ratio should sit between the gallery and shutter", mainUi.contains("layoutFilutroBottomTool(R.id.filutro_aspect_ratio"));
        assertTrue("Multiple exposure should sit between the gallery and shutter", mainUi.contains("layoutFilutroBottomTool(R.id.filutro_multiple_exposure"));
        assertTrue("Bottom tools should align to the gallery rail", mainUi.contains("toolParams.addRule(RelativeLayout.ALIGN_BOTTOM, R.id.gallery)"));
        assertTrue("Landscape needs its own right-hand shooting rail", mainUi.contains("layoutFilutroLandscapeControls();"));
        assertTrue("Landscape shutter must be at the top right", mainUi.contains("private void layoutFilutroLandscapeControls()") && mainUi.contains("shutterParams.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE)"));
        assertTrue("Landscape gallery must finish the right-side rail", mainUi.contains("galleryParams.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM, RelativeLayout.TRUE)"));
        assertTrue("Landscape LUT should begin below the shutter", mainUi.contains("layoutFilutroLandscapeTool(R.id.filutro_lut, R.id.take_photo, spacing)"));
        assertTrue("Landscape aspect ratio should follow LUT", mainUi.contains("layoutFilutroLandscapeTool(R.id.filutro_aspect_ratio, R.id.filutro_lut, spacing)"));
        assertTrue("Landscape multiple exposure should follow aspect ratio", mainUi.contains("layoutFilutroLandscapeTool(R.id.filutro_multiple_exposure, R.id.filutro_aspect_ratio, spacing)"));
        assertTrue("Landscape camera switch must not overlap the gallery rail", mainUi.contains("switchParams.addRule(RelativeLayout.LEFT_OF, R.id.take_photo)"));
        assertTrue("Landscape zoom must sit immediately left of the shutter rail", mainUi.contains("zoomParams.addRule(RelativeLayout.LEFT_OF, R.id.take_photo)"));
        assertTrue("Landscape zoom must be vertical", mainUi.contains("zoom.setRotation(-90.0f)"));
        assertTrue("Landscape top controls must become a vertical left rail", mainUi.contains("layoutFilutroLandscapeTopControls()") && mainUi.contains("topControlsLayout.setOrientation(LinearLayout.VERTICAL)"));
        assertTrue("Landscape top controls must stay clear of the preview", mainUi.contains("topControlsParams.addRule(RelativeLayout.ALIGN_PARENT_LEFT, RelativeLayout.TRUE)") && mainUi.contains("topControlsParams.addRule(RelativeLayout.CENTER_VERTICAL, RelativeLayout.TRUE)"));
        assertTrue("Landscape left-rail icons need individual optical alignment", mainUi.contains("setFilutroTopControlOffset(R.id.popup, -4") && mainUi.contains("setFilutroTopControlOffset(R.id.filutro_hdr, 7") && mainUi.contains("setFilutroTopControlOffset(R.id.cycle_flash, 0") && mainUi.contains("setFilutroTopControlOffset(R.id.exposure, -5") && mainUi.contains("setFilutroTopControlOffset(R.id.exposure_lock, 4") && mainUi.contains("setFilutroTopControlOffset(R.id.settings, 1"));
    }

    @Test
    public void filutroControlAssetsIncludeDynamicStates() {
        File root = new File("src/main/res/drawable-nodpi");
        if( !root.isDirectory() ) {
            root = new File("app/src/main/res/drawable-nodpi");
        }
        String[] names = {
                "ic_filutro_exposure.png",
                "ic_filutro_exposure_active.png",
                "ic_filutro_exposure_lock.png",
                "ic_filutro_exposure_unlock.png",
                "ic_filutro_flash_off.png",
                "ic_filutro_flash_auto.png",
                "ic_filutro_flash_on.png",
                "ic_filutro_gallery_empty.png"
        };
        for( String name : names ) {
            assertTrue(name, new File(root, name).isFile());
        }
    }
}
