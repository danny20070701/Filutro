package net.sourceforge.opencamera;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class FilutroPhotoModeTest {
    @Test
    public void hdrToggleUsesTheNativeHdrModeAndReturnsToStandard() {
        assertEquals(FilutroPhotoMode.HDR, FilutroPhotoMode.toggleHdr(FilutroPhotoMode.STANDARD, true));
        assertEquals(FilutroPhotoMode.STANDARD, FilutroPhotoMode.toggleHdr(FilutroPhotoMode.HDR, true));
    }
}
