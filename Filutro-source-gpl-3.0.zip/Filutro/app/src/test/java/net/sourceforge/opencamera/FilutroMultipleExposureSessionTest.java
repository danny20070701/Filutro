package net.sourceforge.opencamera;

import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

public class FilutroMultipleExposureSessionTest {
    @Test
    public void returnsCompletedFramesThenResetsForTheNextComposite() {
        FilutroMultipleExposureSession session = new FilutroMultipleExposureSession(3);

        assertNull(session.add(new byte[] {1}));
        assertNull(session.add(new byte[] {2}));
        List<byte[]> complete = session.add(new byte[] {3});

        assertEquals(3, complete.size());
        assertEquals(0, session.capturedCount());
    }

    @Test
    public void exposesPendingFramesForTheLiveGuidancePreview() {
        FilutroMultipleExposureSession session = new FilutroMultipleExposureSession(3);
        byte[] firstFrame = new byte[] {1};

        assertNull(session.add(firstFrame));
        List<byte[]> pendingFrames = session.pendingFrames();

        assertEquals(1, pendingFrames.size());
        assertEquals(1, pendingFrames.get(0)[0]);
    }
}
