package net.sourceforge.opencamera;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class FilutroLutPresetsTest {
    @Test
    public void warmFilmPresetAddsWarmthWithoutChangingAlpha() {
        int output = FilutroLutPresets.forId(FilutroLutPresets.WARM_FILM).apply(0x80406080);

        assertTrue(((output >>> 24) & 0xFF) == 0x80);
        assertTrue(((output >>> 16) & 0xFF) > 0x40);
        assertTrue((output & 0xFF) < 0x80);
    }

    @Test
    public void exposesTheFortyBuiltInFilutroLooks() {
        assertEquals(40, FilutroLutPresets.entries().size());
    }
}
