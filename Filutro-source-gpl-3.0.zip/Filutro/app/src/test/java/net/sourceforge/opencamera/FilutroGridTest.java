package net.sourceforge.opencamera;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class FilutroGridTest {
    @Test
    public void exposesTheCompleteGridCatalogUsedByTheFilutroPicker() {
        assertEquals(12, FilutroGrid.entries().length);
        assertEquals("preference_grid_none", FilutroGrid.entries()[0].value);
        assertEquals("preference_grid_diagonals", FilutroGrid.entries()[11].value);
    }
}
