package net.sourceforge.opencamera;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class FilutroMultipleExposureProcessorTest {
    @Test
    public void screenBlendKeepsBlackAndAddsLightFromBothFrames() {
        assertEquals(0xFF000000, FilutroMultipleExposureProcessor.screenBlend(0xFF000000, 0xFF000000));
        assertEquals(0xFFFFFFFF, FilutroMultipleExposureProcessor.screenBlend(0xFFFFFFFF, 0xFF123456));
        assertEquals(0xFFC00000, FilutroMultipleExposureProcessor.screenBlend(0xFF800000, 0xFF800000));
    }
}
