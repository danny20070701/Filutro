package net.sourceforge.opencamera.preview.camerasurface;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.lang.reflect.Field;

public class FilutroLutSurfaceShaderTest {
    @Test
    public void fragmentShaderDeclaresSampler3dPrecision() throws Exception {
        Field field = FilutroLutSurface.class.getDeclaredField("FRAGMENT_SHADER");
        field.setAccessible(true);
        String fragmentShader = (String) field.get(null);

        assertTrue(fragmentShader.contains("precision highp sampler3D;"));
    }

    @Test
    public void fragmentShaderMatchesCamera2LandscapeRotationDirection() throws Exception {
        Field field = FilutroLutSurface.class.getDeclaredField("FRAGMENT_SHADER");
        field.setAccessible(true);
        String fragmentShader = (String) field.get(null);

        assertTrue("ROTATION_90 must use the Camera2 inverse sampling direction", fragmentShader.contains("if (uRotationDegrees == 90) coordinate = vec2(1.0 - coordinate.y, coordinate.x);"));
        assertTrue("ROTATION_270 must use the Camera2 inverse sampling direction", fragmentShader.contains("else if (uRotationDegrees == 270) coordinate = vec2(coordinate.y, 1.0 - coordinate.x);"));
    }
}
