package net.sourceforge.opencamera;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class FilutroCubeLutTest {
    @Test
    public void identityCubePreservesArgbChannels() {
        FilutroCubeLut lut = FilutroCubeLut.parse("LUT_3D_SIZE 2\n" +
                "0 0 0\n0 0 1\n0 1 0\n0 1 1\n1 0 0\n1 0 1\n1 1 0\n1 1 1\n");

        assertEquals(0xCC804020, lut.apply(0xCC804020));
    }

    @Test
    public void exportsTheThreeDimensionalTextureBytesUsedByPreview() {
        FilutroCubeLut lut = FilutroCubeLut.parse("LUT_3D_SIZE 2\n" +
                "0 0 0\n0 0 1\n0 1 0\n0 1 1\n1 0 0\n1 0 1\n1 1 0\n1 1 1\n");

        assertEquals(2, lut.size());
        assertEquals(24, lut.toRgbBytes().length);
        assertEquals((byte) 0xFF, lut.toRgbBytes()[23]);
    }
}
