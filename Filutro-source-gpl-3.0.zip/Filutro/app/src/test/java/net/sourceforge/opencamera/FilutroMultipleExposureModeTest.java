package net.sourceforge.opencamera;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class FilutroMultipleExposureModeTest {
    @Test
    public void parsesOnlySupportedFrameCounts() {
        assertEquals(0, FilutroMultipleExposureMode.parse("off"));
        assertEquals(2, FilutroMultipleExposureMode.parse("2"));
        assertEquals(4, FilutroMultipleExposureMode.parse("4"));
        assertEquals(0, FilutroMultipleExposureMode.parse("5"));
    }
}
