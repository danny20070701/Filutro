package net.sourceforge.opencamera;

import org.junit.Test;

import static org.junit.Assert.assertFalse;

public class FilutroPhotoOnlyPolicyTest {
    @Test
    public void videoRequestsAlwaysResolveToPhotoMode() {
        assertFalse(FilutroPhotoOnlyPolicy.shouldUseVideoMode(true));
        assertFalse(FilutroPhotoOnlyPolicy.shouldUseVideoMode(false));
    }
}
