# Filutro

Filutro is a photo-only Android camera app with real-time LUT preview and baked-in JPEG output. It builds on the mature camera pipeline of Open Camera while providing a Filutro-focused interface and shooting workflow.

## Features

- Real-time 3D LUT preview, built-in looks, and `.cube` LUT import
- LUT-rendered JPEG output
- Photo aspect-ratio guides and output crops
- Native Open Camera HDR capture
- Two to four frame multiple exposure with a live ghost preview
- Configurable shutter sounds and capture feedback
- Photo-only interface with location metadata support

## Open Camera Foundation

Filutro is a modified derivative of [Open Camera](https://opencamera.org.uk/), an Android camera application by Mark Harman and contributors. The original Open Camera source is available at <https://sourceforge.net/p/opencamera/code/ci/master/tree/>.

Filutro retains Open Camera's Android camera, autofocus, capture, image saving, and compatibility foundations. Filutro-specific changes include the camera UI, LUT processing and preview, multiple exposure workflow, aspect-ratio controls, shutter feedback, and project branding.

Created by PCIE / 班禪.

## License

This repository, including the Filutro modifications and the incorporated Open Camera source code, is distributed under the GNU General Public License, version 3 or later. See [LICENSE](LICENSE).

When distributing modified builds, provide the corresponding source code and preserve the applicable copyright, attribution, and license notices.
